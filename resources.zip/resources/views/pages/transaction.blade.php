@extends('layouts.nav')
@section('content')
<section class="transaction-hero">
    <div class="info">
        <h1>
            مرحبا بكم في منصة تسيير معاملات العقارات للمغتربين
        </h1>
        <p>نحن هنا لتسهيل وتبسيط جميع معاملاتكم القانونية الخاصة بالعقارات، أينما كنتم حول العالم.</p>
    </div>
</section>
<!-- start transaction-->
<section class="start-transaction">
    <h2>ابدأ معاملتك</h2>
    <div class="body">
        <div class="form">
            <form action="#">
                <select name="type" id="">
                    <option value="" selected>نوع المعاملة</option>
                    <option value="buy">شراء</option>
                    <option value="rent">ايجار</option>
                </select>

                <textarea placeholder="تفاصيل العقار " rows="4" name=""></textarea>

                <input type="text" placeholder="الوثائق المطلوبة" name="">
                <input type="text" placeholder="التكلفة التقديرية" name="">

                <select name="type" id="">
                    <option value="" selected>البلد / المدينة </option>
                    <option value="">سوريا-حمص</option>
                </select>

                <select name="type" id="">
                    <option value="" selected>وسائل الاتصال</option>
                    <option value="">وسيلة-1</option>
                    <option value="">وسيلة-2</option>
                </select>

                <div class="btn-container">
                    <button type="submit" class="btn-primary">ارسال </button>
                    <a class="btn-sec" href="./confermTransaction.html">مراجعة قبل التأكيد </a>
                </div>
            </form>
        </div>
    </div>
</section>
@endsection
